package tlvprocessor;

public enum Commands {
	UPPRCS,REPLCE
}
