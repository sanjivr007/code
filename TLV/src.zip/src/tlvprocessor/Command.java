package tlvprocessor;

public interface Command {
	public String executeCommand(Values data);

}
